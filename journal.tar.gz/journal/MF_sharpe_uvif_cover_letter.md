# Cover Letter

Dear Editor,

Please consider the manuscript, "Sharpe-Ratio Inference at the Date Boundary in Financial Panels," for publication as an Article in Modern Finance.

The paper is a financial econometrics methodology study using public Kenneth French panels, AQR factor series, and Monte Carlo designs. It examines how Sharpe-ratio evidence can be misstated when selected rows in an entity-time panel are treated as independent observations even though the economically relevant payoff is a date-level portfolio return.

The simulations show that row-naive testing rejects about 35 percent of the time at a nominal 5 percent level under dependent zero-edge nulls, while date-level HAC and dependent-bootstrap procedures remain much closer to nominal size. The public benchmarks show that the correction preserves canonical momentum evidence but removes weaker stress-panel claims. The manuscript is positioned as a methods paper for evaluating panel-based Sharpe evidence rather than as a new anomaly or trading-rule paper.

The submission is original, is not under consideration elsewhere, and has not been published in a peer-reviewed outlet. Separate blinded manuscript files, a separate blinded appendix, an anonymized replication ZIP, and a separate title page have been prepared in accordance with the journal's review requirements.

Potential reviewers:

1. [Name], [Affiliation], [Email]
2. [Name], [Affiliation], [Email]
3. [Name], [Affiliation], [Email]

Sincerely,

Dhananjay S. Chauhan
Independent Researcher, India
ORCID: https://orcid.org/0009-0003-1049-2213
Email: dschauhan08.me@gmail.com
