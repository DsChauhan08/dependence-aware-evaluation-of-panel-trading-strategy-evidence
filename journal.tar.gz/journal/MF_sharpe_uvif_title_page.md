# Title Page

Title: Sampling-Boundary Distortion in Sharpe Ratio: Evidence from Financial Panels

Author: Dhananjay S. Chauhan

Affiliation: Independent Researcher, India

Corresponding author: Dhananjay S. Chauhan, Independent Researcher, India

Contact address: Delhi, National Capital Territory of Delhi, India; Email: dschauhan08.me@gmail.com

Email: dschauhan08.me@gmail.com

ORCID: https://orcid.org/0009-0003-1049-2213

Public repository: https://github.com/DsChauhan08/dependence-aware-evaluation-of-panel-trading-strategy-evidence

Keywords: Sharpe ratio; panel data; cross-sectional dependence; serial dependence; HAC/bootstrap inference; portfolio evaluation

JEL Codes: C12; C15; G11; G12; G17
