# Anonymous Replication Package

This double-blind review package contains public-data loaders, simulation code, generated aggregate artifacts, and tests needed to reproduce the manuscript tables and figures. Author-identifying title-page material, cover letters, personal repository links, and public-archive metadata are excluded.

Run `python -m pytest -q tests/test_audit_methods.py` for the method checks. The manuscript artifacts were rendered from the public aggregates using the included rendering utility.
